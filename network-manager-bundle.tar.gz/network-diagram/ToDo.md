# ToDo

- Any styling changes you can think of to the tables to improve from a frontend UI persective? Make sure to use any relevant skills you have.

- include credentials, av, agents in properties window

- have icons for agents
- icons for agents to show up on the network map
- Change title depending on page
- A section in the device page for software
- A list of info that appears based on infoWrmation on the device page
- Fix elements lagging behind when changing between light and dark mode
- Doco on the sql database for queries

## Agents

- FEATURE: Add a network diagram (toogle in the project settings?)

## Devices

- NEW FEATURE: Option to upload a CSV to import. After clicking the button it should have a modal which gives an example of how it should be structured. Add an option to download a template users can use to fill in to upload.
- NEW FEATURE: Add additional domains field (comma separated?)
- NEW FEATURE: Add DNS records option (similar to historicaldns.org)
- NEW FEATURE: Add folder tree view
- NEW FEATURE: Add tree view for process listing
- NEW FEATURE: Add an option to import a .txt file, it should scroll through for output from the text file that matches parsed fields and confirm if the user wants to add them.
- NEW FEATURE: Add a device option for LXC / Docker / Kubernetes container types
- FEATURE CHANGE: Add an option to the devices page to include or remove other fields from being displayed such as MAC Address
- FEATURE CHANGE: Either change parsing for ps or support multiple formats, add to the input placeholder text what it supports
- FEATURE: Add User History
- FEATURE: Add software list

## Subnets

- NEW FEATURE: DNS Records (Internal and External), tie a DNS record to a device

## Credentials

- NEW FEATURE: Add a search filter similar to a Confluence filter search bar on a table

## Network Diagram

- DESIGN: Add icons and options to hide border, include the border settings in the default project menu
- NEW FEATURE: Auto layout, have options of what to add (all, favourited, devices with certain tags...)
- NEW FEATURE: Auto layout, where possible don't place a device above an edge
- NEW FEATURE: Add an option to export and import the network diagram
- NEW FEATURE: Add grouping
- NEW FEATURE: Add a drawing feature on the network diagram
- NEW FEATURE: Add an option to select the default style for different device types
- FEATURE CHANGE: For the network diagram change the colour selection boxes for connections, devices and subnets. Instead of having a circle of preselected colours have a more flexible popup window to select a colour, and when hovering over the selection box show the hex value as a tooltip.
- FEATURE CHANGE: Change the star icon in the network diagram
- FEATURE CHANGE: Change the diagram lock location so it has more padding, and/or give it rounded edges
- FEATURE CHANGE: Change the network diagram to remember the last lock setting
- DESIGN: Checkbox to display VLAN ID
- DESIGN: Hide option for the overall view box?
- DESIGN: Add opaqueness to subnet background colour
- DESIGN: Show zoom percentage
- DESIGN: Add animated edges (ref: https://reactflow.dev/examples/edges/animating-edges)
- DESIGN: Add delete edge on drop (ref: https://reactflow.dev/examples/edges/delete-edge-on-drop)
- DESIGN: Styles for edge label
- DESIGN: Look into floating edges (ref: https://reactflow.dev/examples/edges/floating-edges)
- DESIGN: Look into markers / arrows (ref: https://reactflow.dev/examples/edges/markers)
- DESIGN: Add icons for hosts
- DESIGN: Only show connector joints when drawing out an edge
- DESIGN: In the network diagram you're unable to make the border colour clear
- DESIGN: Change the location of the search bar in the Network Diagram when it's wrapped because it's out of place on a new line by itself
- DESIGN: Ideas on how to best represent which VMs belong to which hypervisor on the network diagram
- BUG: Only the primary or first IP displays in the list
- DISICION: Colour changes to device/subnet applies to all diagram?

## Firewall

- NEW FEATURE: Firewall rules (host based / iptables & router firewall rules)

## Logs

- NEW FEATURE: Filter timestamp times (Since: `<datetime>`, Until: `<datetime>`) similar to Proxmox System Log
- FEATURE CHANGE: Add notification in logs about how long the logs last for

## Overall / Global

- NEW FEATURE: Router parser. Parse router configs from devices such as pfsense, cisco, unifi, foritnet, juniper, mikrotik. Display them in a nice table similar to unifi (image attached) to make it more human readable.
- NEW FEATURE: List of IPs allowed
- NEW FEATURE: Have linked boxes, in case 1 host is in multiple subnets
- NEW FEATURE: Add a search bar / button at the top of the navigation bar that searches site wide. When you press to type it should open up a popup / modal for searching
- NEW FEATURE: Search bar to search on: hosts with the same user, hosts with a certain process
- NEW FEATURE: Add user authentication with roles for users and admins. Only admins should be able to see the Admin Settings. Add support for authenticating with GitLab account.
- NEW FEATURE: Integrate LDAP authentication
- NEW FEATURE: Add groups and roles (User Bob part of Team A with edit perms. User Bob can view Team B)
- NEW FEATURE: PCAP Viewer
- NEW FEATURE: Add GraphQL (Neo4J)
- NEW FEATURE: Import nmap output (XML?)
- NEW FEATURE: Overview Window (includes fields like short written overview of the project, number of hosts, number that have access to — refer to pentest.ws/neuron.ws for example)
- NEW FEATURE: Increase the number of default images/icons
- NEW FEATURE: Create email reminders for certain events
- FEATURE CHANGE: Change the backup option to export each section as different JSON files and store in a zip. This way individual options can be imported.
- FEATURE CHANGE: Change output for a host to be text with an optional parse button
- FEATURE CHANGE: Change the style of the buttons (need to play around with this)
- FEATURE CHANGE: Change the image resizing for pictures. Change it so the image can stretch
- FEATURE CHANGE: For the tables in Devices, Subnets and Credentials, add an option to hide/unhide certain columns
- DESIGN: Add option for a picture left of the title
- BUG: When the navigation bar is minimized, the rows aren't aligned compared to when the navigation bar is expanded. Likely a padding or size issue with the dropdown box.

## Still Deciding

- Create a gitbook/wiki for the project
- Add Bookmarks menu
- Change database from SQLite3 to MariaDB
- Create a graphical timeline of events
- Toggle icons for interested / not interested (pentest feature)
- Infrastructure Page

## Checks

- CHECK: Check what on the network diagram is stored in the localDatabase and change what's needed