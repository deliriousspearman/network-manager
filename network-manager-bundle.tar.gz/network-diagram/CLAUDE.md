# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

```bash
# Requires nvm: export NVM_DIR="$HOME/.nvm" && . "$NVM_DIR/nvm.sh"
npm run build        # Build server (tsc) + client (vite build)
npm test             # Run all tests once (vitest run)
npm run test:watch   # Run tests in watch mode (vitest)
```

## Service Management

Use `systemctl --user` to manage the dev service instead of `npm run dev`:

```bash
systemctl --user status network-manager    # Check service status
systemctl --user restart network-manager   # Restart after code changes
systemctl --user stop network-manager      # Stop the service
systemctl --user start network-manager     # Start the service
```

Only use `npm run` for commands not covered by systemctl (e.g., `npm run build`, `npm install`).

## Architecture

npm workspaces monorepo with three packages:

- **shared/** — TypeScript type definitions only (`types.ts`), imported by both client and server as `shared/types`
- **server/** — Express + better-sqlite3, ESM (`"type": "module"`). Uses `.js` extensions in imports (required for ESM even with tsx). Express app is configured in `app.ts` (exported for testing), server startup in `index.ts`
- **client/** — React 18 + Vite, with React Router v6 and TanStack React Query v5

### Server

**Database**: SQLite with WAL mode and foreign keys enabled. Migrations in `server/src/db/migrations/` run automatically on startup from `db/connection.ts` (not a separate step). This means tables exist before any module-level `db.prepare()` calls in route files.

**Routes** (`server/src/routes/`): Each route file exports a Router. Multi-row writes use `db.transaction()` for atomicity (e.g., creating a device with multiple IPs). Prepared statements used at module level are fine because connection.ts runs migrations before exporting.

**Parsers** (`server/src/parsers/`): Registry in `index.ts` maps command type strings to parser functions. Each parser is `(raw: string) => Row[]`. The `commandOutputs` route calls the parser and inserts raw + parsed data in a single transaction.

### Client

**Data fetching**: TanStack Query with 30s stale time. API wrappers in `client/src/api/` are plain fetch functions. Mutations invalidate query keys on success.

**Diagram**: `@xyflow/react` v12+ (import from `@xyflow/react`, not old `reactflow`). Custom node types registered as `nodeTypes` object. Subnet nodes use React Flow's `parentId`/`extent: 'parent'` for containment — parent nodes must appear before children in the nodes array. Position changes are debounced (500ms) before saving to server.

### Key Data Flow

Command output submission: POST raw text → server parses via registered parser → stores raw output + parsed rows in transaction → client fetches parsed data for display in typed table components.

Diagram positions are stored separately from devices/subnets (`diagram_positions` / `subnet_diagram_positions` tables), so a device can exist without being on the diagram.

## Git & GitLab

- Remote: https://gitlab.hedgylabs.org/jake/network-manager
- Commit identity: jake / jake@mail.lan (local config)
- **Commit and push regularly**: After completing each logical unit of work (a feature, a fix, a refactor), stage the changes, commit with a clean descriptive message, and push to origin. Do not let work accumulate uncommitted. This ensures we never lose progress and can revert easily.
- Commit messages should be concise and describe the "why" — e.g. "Add subnet VLAN filtering to device list" not "Update DeviceList.tsx".
- Push to `origin main` after each commit.
