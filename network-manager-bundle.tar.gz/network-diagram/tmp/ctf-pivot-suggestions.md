# CTF Pivot — Suggested Features & Changes

## Context

The project is currently a network inventory + diagram tool aimed at home-lab / network management. The user is exploring whether it could also serve as a workspace for cybersecurity CTFs (HackTheBox, TryHackMe, OffSec labs, etc.).

A CTF workflow has a specific shape that this tool is *almost* set up for, but is missing a handful of first-class concepts. The good news: most of the heavy lifting (devices, IPs, ports, credentials, command parsers, project isolation, diagram, notes, attachments, activity log) already exists. The pivot is mostly *additive* — new tables and parsers — rather than a rewrite.

This document collects suggestions grouped by theme so the user can pick which directions to pursue.

---

## What's already a strong fit (reuse, don't rebuild)

These existing features map almost 1:1 to CTF needs:

- **Projects** ([server/src/routes/projects.ts](server/src/routes/projects.ts)) → one per box / one per CTF event. Already isolated per-project DB scoping.
- **Devices + multi-IP** ([shared/types.ts:30-83](shared/types.ts#L30-L83)) → target hosts. Multi-IP fits dual-homed pivot boxes.
- **device_ports** (migration 025) → already tracks port + state + service. Just needs version/banner fields.
- **Credentials** with file attachments ([shared/types.ts:534-547](shared/types.ts#L534-L547)) → already perfect for storing SSH keys, found passwords, password files. The `used` and `hidden` flags map to "tested" and "discarded".
- **Command output parsers** ([server/src/parsers/index.ts](server/src/parsers/index.ts)) → `ps`, `netstat`, `last`, `ip a`, `ip r`, `mount`, `systemctl`, `arp` are exactly what you run after getting a foothold (post-exploitation enum).
- **PCAP parser** → already extracts hosts/IPs/MACs/ports.
- **Tags** → can flag `owned-user`, `owned-root`, `vulnerable`, `pivoted`, etc. without schema changes.
- **Rich notes** on devices → per-host writeup space.
- **Activity log** ([server/src/routes/logs.ts](server/src/routes/logs.ts)) → naturally becomes the attack timeline.
- **Diagram** with annotations + custom icons → visualize the kill chain / pivot path.

---

## Suggested new features

### 1. Findings / Vulnerabilities (highest value)

A `findings` table scoped to a device (or project for project-wide issues):

- `id, project_id, device_id, port_id (nullable), title, description, severity, cvss, cve, status, exploited_at, evidence`
- Severity: info / low / medium / high / critical
- Status: open / confirmed / exploited / patched / false-positive
- New route file: `server/src/routes/findings.ts`
- New types in `shared/types.ts`
- UI: a "Findings" tab on the device page, plus a project-level findings table.
- Diagram integration: badge on device nodes when they have unresolved high/critical findings (the existing `status` indicator pattern in NodePrefs can be reused).

### 2. Flag tracking

A `flags` table — small but defines the "CTF" identity:

- `id, project_id, device_id, type (user|root|other), value (hash/text), captured_at, points`
- Optional `submitted` boolean for platforms that score.
- Project overview shows captured/total flag count.
- Could surface as a small ⚑ badge on the device node when captured.

### 3. Service fingerprinting (extend `device_ports`)

Migration to add columns to `device_ports`:

- `version` (e.g. "Apache 2.4.49"), `banner` (raw), `product`, `extra_info`
- Lets nmap-style enrichment land somewhere structured.

### 4. Nmap parser (already in ToDo line 86)

Already on the existing roadmap and is the highest-impact CTF parser. Three formats worth supporting:

- **`-oX` (XML)** — richest, easiest to parse cleanly
- **`-oG` (greppable)** — common copy/paste from terminals
- **`-oN` (normal)** — what most people paste

Should populate `device_ports` (with the new version/banner fields) and optionally auto-create devices for hosts not yet in the inventory.

### 5. Additional parsers tuned for CTF

Slot into the existing parser registry pattern in [server/src/parsers/index.ts](server/src/parsers/index.ts):

- **gobuster / feroxbuster / dirb** → discovered web paths (status, size, redirect)
- **nikto** → web vuln findings → could feed straight into the `findings` table
- **enum4linux / smbmap** → SMB shares + users
- **linpeas / winpeas** → privesc candidates (heavy parsing, but high reward)
- **hydra / medusa** → successful credential pairs → auto-add to credentials table
- **searchsploit** → exploit candidates per service version
- **whatweb** → web stack fingerprint

### 6. Hashes / loot

Cracking workflow as a sibling to credentials:

- `hashes` table: `hash, type (NTLM, MD5, bcrypt, …), source_device_id, plaintext, cracked_at, status`
- When a hash is cracked, optionally auto-create a credential.

### 7. Attack path / kill chain on the diagram

This is where the diagram becomes uniquely valuable vs. note-only tools:

- Connection types extended with `pivot` and `exploited` edge types (just a string addition to `Connection.connection_type`)
- Edge labels can already carry text — use them for "RCE via CVE-2021-41773" etc.
- Numbered annotation overlays showing attack sequence (annotations already exist).
- A device-status field of `compromised` joining `up/down/warning/unknown`.

### 8. Privilege / foothold tracking

Per-device lightweight state:

- `current_access` (none / user / admin / root / system)
- `foothold_method` (free text: "CVE-X", "Default creds", "SSRF→file read")
- `first_user_at`, `first_root_at` timestamps → drives the timeline view.

### 9. Quick command launcher / per-service playbooks

Static, project-wide library of common commands templated per service:

- Service "smb" → list of `enum4linux -a {ip}`, `smbclient -L //{ip}` …
- Service "http" → `gobuster dir -u http://{ip} -w …`, `nikto -h {ip}`
- Click → copy to clipboard with `{ip}` substituted from selected device.
- No execution server-side (avoids security/sandboxing concerns); pure copy/paste helper.

### 10. Walkthrough / report export

Markdown export of a project that combines:

- Device list with ports + services
- Findings with severity
- Captured flags
- Timeline of activity log
- Selected command outputs

Useful for OSCP-style reports and HTB write-ups. Could reuse the existing backup/export system as a starting point.

### 11. OSINT bucket

A small free-form table per project for: emails, usernames, domains, subdomains, leaked-cred references. Often the difference between getting initial access or not.

---

## Suggested tweaks to existing features (smaller wins)

- **Tag presets**: ship default CTF tags (`owned-user`, `owned-root`, `low-hanging`, `rabbit-hole`, `pivot-point`).
- **Status field**: add `compromised` to device `status` enum, with an obvious icon on the diagram.
- **Credentials**: add a `works_on` multi-device field — one cred often unlocks multiple boxes.
- **Project metadata**: add fields like `platform` (HTB / THM / OffSec / custom), `difficulty`, `started_at`, `pwned_at`.
- **Search**: extend the existing global search to include findings + flags once those tables exist.
- **Activity log**: add resource types for `finding` and `flag` so they appear in the timeline naturally.

---

## What I'd *not* recommend

- **Building an exploit launcher / live attack runner.** Stays in scope as a *workspace* not a *toolkit*. Avoid security/sandbox liability and stay vendor-neutral with the user's existing tools (Kali, Burp, msfconsole).
- **Replacing existing tools.** The value is *aggregation and visualization*, not reimplementing nmap/burp.
- **Authentication & multi-user (until later).** It's already on the ToDo list — for personal CTF use, not blocking.

---

## Critical files for any CTF pivot work

- [shared/types.ts](shared/types.ts) — all new types go here
- [server/src/db/migrations/](server/src/db/migrations/) — new migrations follow the existing 001…025 numbering
- [server/src/parsers/index.ts](server/src/parsers/index.ts) — parser registry, where new tools plug in
- [server/src/routes/](server/src/routes/) — one new route file per new resource (`findings.ts`, `flags.ts`, `hashes.ts`)
- [client/src/pages/DevicePage](client/src/pages/) — where per-device tabs live
- [client/src/components/diagram/nodes/](client/src/components/diagram/nodes/) — for any new node badges/indicators

---

## Verification (once features land)

For any of these features the verification path is the same:

1. `npm run build` succeeds (server tsc + client vite)
2. `npm test` passes; add parser unit tests beside existing ones in `server/src/parsers/__tests__/`
3. `systemctl --user restart network-manager`
4. Smoke-test the new tables/routes via the SQL Query route or curl
5. Create a fresh CTF project end-to-end: add a target device, paste an nmap result, create a finding, capture a flag, see them all in the project overview and on the diagram

---

## User direction (from clarifying questions)

- **Mode**: Exploration only — no implementation yet. This document is a discussion menu.
- **Most interesting direction**: **Attack path on the diagram** (section 7 above).

### Why "attack path on diagram" is the most interesting starting point

It's the angle where this project would be *differentiated* from existing CTF tooling (Notion templates, CherryTree, pentest.ws, etc.). Most pentest note-takers are document-shaped. This one is graph-shaped — and a graph is exactly how an attack path actually looks.

### What an "attack path" feature could mean concretely

A short menu of additions, smallest → biggest:

1. **Tiny win — `compromised` status.** Add `compromised` to the device `status` enum next to `up/down/warning/unknown`. Pick a distinctive icon (skull, flag, etc.). Costs ~1 migration + 1 icon. Suddenly the diagram tells you which hosts are owned at a glance.

2. **Per-device access level.** A new `current_access` field (`none/user/admin/root/system`) shown as a small badge on the node. Lets you see "I have user on box A, root on box B" while looking at the map.

3. **Edge types for compromise.** Extend `Connection.connection_type` with `pivot` and `exploited`. Style them distinctly (animated dashed red?). Use the existing edge label feature to write the exploit name ("CVE-2021-41773", "Pass-the-hash", "Reused creds from box A").

4. **Numbered attack sequence.** Reuse the existing `DiagramAnnotation` system to drop numbered markers (①②③) on the map. The order tells the story: enum → foothold → privesc → pivot.

5. **Foothold timestamps.** `first_user_at` / `first_root_at` per device. Combined with the existing activity log, this becomes a true attack timeline you can replay.

6. **Auto-draw from activity log.** Stretchier idea: when you log "exploited box B from box A", an edge appears automatically. This is the "make it feel alive" move but the most complex.

### Why this is a good fit for *this* codebase specifically

- React Flow already supports the styling needed (animated edges are even on the existing ToDo line 52).
- Connections, annotations, statuses, and node prefs are all already first-class concepts — these are all *additive* changes, not refactors.
- No new tables required for items 1–4. Items 5–6 need only small column additions.
- It composes cleanly with the rest of the CTF menu later (findings/flags can light up nodes that already have a `compromised` status).

### Not committing yet

Per the user's answer: this is exploration. No code changes proposed. When/if the user wants to actually build any of this, a focused implementation plan should be written for whichever specific item(s) above they pick.
