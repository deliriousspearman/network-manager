# Security Audit: Network Manager Application

## Context

This audit covers the full-stack network diagram/manager application (Express + SQLite backend, React frontend). The app manages network devices, credentials, subnets, command outputs, and diagram layouts. It stores sensitive data including plaintext passwords and SSH keys. The findings below are ordered by severity.

---

## CRITICAL Findings

### 1. SQL Query Route — Cross-Project Data Leak
**File:** [sqlQuery.ts:62-84](server/src/routes/sqlQuery.ts#L62-L84)

The `/api/projects/:projectId/query` endpoint accepts arbitrary user-written SQL and executes it against a readonly database connection. While it correctly blocks writes (INSERT/UPDATE/DELETE/DROP), it does **not enforce project scoping**. The `projectId` is passed as a named parameter (`{ projectId }`), but the user is never required to use it.

**Exploit:** `SELECT * FROM credentials` returns **all credentials from all projects**, including plaintext passwords. The readonly connection prevents writes, but any user with access can read the entire database across project boundaries.

**Fix:** Either:
- Wrap the user query in a CTE/subquery that enforces `WHERE project_id = :projectId` on every table, or
- Use SQLite VIEWs scoped to the current project, or
- Parse the query AST to verify project_id filtering (complex), or
- Create a temporary schema with only project-scoped data (simplest: create filtered views per-request)

### 2. No Authentication or Authorization
**Files:** [app.ts](server/src/app.ts), [projectScope.ts](server/src/middleware/projectScope.ts)

There is zero authentication. Anyone who can reach the server can:
- Read/modify/delete all data across all projects
- Export backups including plaintext credentials
- Execute arbitrary SELECT queries against the database
- Create/delete projects

`projectScope` middleware only verifies a project *exists*, not that the requester is authorized to access it.

**Fix:** Add authentication middleware (JWT, session-based, or HTTP Basic Auth behind a reverse proxy). For a LAN-only tool, even a simple shared secret/API key would be a significant improvement.

### 3. Plaintext Credential Storage
**Files:** [credentials.ts:12-19](server/src/routes/credentials.ts#L12-L19), [backup.ts:43](server/src/routes/backup.ts#L43)

Passwords are stored in plaintext in SQLite and:
- Returned in full in list endpoints (line 13: `c.password` in SELECT)
- Searchable via LIKE queries (line 41: `c.password LIKE ?`)
- Included in backup exports (backup.ts line 43)
- Displayed in plaintext in the UI ([CredentialList.tsx:274](client/src/components/credentials/CredentialList.tsx#L274))
- Exported to CSV with plaintext passwords
- Copyable to clipboard via bulk actions

**Fix:** Encrypt credentials at rest using a server-side encryption key (e.g., AES-256-GCM with a key from an environment variable or file). Decrypt only when explicitly requested. Remove password from search/list queries — provide a separate "reveal" endpoint.

---

## HIGH Findings

### 4. ORDER BY SQL Injection (Mitigated but Fragile)
**Files:** [devices.ts:43-44,53,61](server/src/routes/devices.ts#L43-L44), [subnets.ts](server/src/routes/subnets.ts), [agents.ts](server/src/routes/agents.ts), [credentials.ts:57-58,67,71](server/src/routes/credentials.ts#L57-L58)

Sort column and direction are interpolated into SQL:
```typescript
const sortCol = DEVICE_SORT_MAP[req.query.sort as string] || 'd.name';
const sortDir = req.query.order === 'desc' ? 'DESC' : 'ASC';
// ... ORDER BY ${sortCol} ${sortDir}
```

The whitelist map (`DEVICE_SORT_MAP`) and binary direction check make this **currently safe** — an unrecognized sort key falls back to `'d.name'`, and `sortDir` can only be `'DESC'` or `'ASC'`. However, the pattern of interpolating into SQL is fragile and would become vulnerable if someone adds a code path that skips the whitelist.

**Fix:** Keep the whitelist approach but add a comment documenting why it's safe. Alternatively, use a CASE expression in the SQL to avoid interpolation entirely.

### 5. Password Field Uses `type="text"`
**File:** [CredentialForm.tsx:207-208](client/src/components/credentials/CredentialForm.tsx#L207-L208)

The password input renders as `type="text"`, making passwords visible while typing and in browser autocomplete/history.

**Fix:** Change to `type="password"` with an optional show/hide toggle.

### 6. Missing Security Headers
**File:** [app.ts](server/src/app.ts)

No security headers are set:
- No `Content-Security-Policy` (CSP)
- No `X-Content-Type-Options: nosniff`
- No `X-Frame-Options` / `frame-ancestors`
- No `Strict-Transport-Security` (HSTS) when SSL is enabled
- No `Referrer-Policy`

**Fix:** Add `helmet` middleware or set these headers manually.

### 7. CORS Allows Null Origin
**File:** [app.ts:43-44](server/src/app.ts#L43-L44)

```typescript
if (!origin) return callback(null, true);
```

Requests with no `Origin` header (e.g., from `curl`, server-to-server, or `file://` pages) bypass CORS entirely. While CORS is primarily a browser protection, this weakens the defense-in-depth posture.

**Fix:** In production, require an origin header or use an API key for non-browser clients.

---

## MEDIUM Findings

### 8. Credential Password in Search Filter
**File:** [credentials.ts:41](server/src/routes/credentials.ts#L41)

The search filter matches against `c.password LIKE ?`. This means searching for a known password fragment can confirm its presence, enabling password enumeration even in a multi-user scenario.

**Fix:** Remove `c.password` from the LIKE filter clause.

### 9. File Upload MIME Type Validation is Client-Supplied
**Files:** [deviceImages.ts](server/src/routes/deviceImages.ts), [deviceAttachments.ts](server/src/routes/deviceAttachments.ts), [diagramIcons.ts](server/src/routes/diagramIcons.ts), [imageLibrary.ts](server/src/routes/imageLibrary.ts)

MIME type is taken from the request body (`req.body.mime_type`). The server validates it against an allowlist (good), but the base64 data content is never validated against the declared MIME type. An attacker could declare `image/png` but upload an executable or HTML file containing JavaScript.

**Fix:** Validate file magic bytes against the declared MIME type before storing.

### 10. Backup Export Includes Plaintext Credentials by Default
**File:** [backup.ts:14,43](server/src/routes/backup.ts#L14)

`includeCredentials` defaults to `true` (`_req.query.includeCredentials !== 'false'`). A GET request to `/api/backup/export` without query parameters returns all credentials with plaintext passwords.

**Fix:** Default `includeCredentials` to `false`. Require explicit opt-in.

### 11. No Content-Length or Row-Count Limit on CSV Import
**File:** [deviceCsvImport.ts](server/src/routes/deviceCsvImport.ts)

CSV import parses all rows in the request body without limiting the number of rows. A large CSV could cause memory exhaustion or long processing times.

**Fix:** Add a row count limit (e.g., 10,000 rows).

### 12. Rich Text Notes — Server-Side Sanitization Missing
**Files:** [DeviceNotesSection.tsx](client/src/components/devices/DeviceNotesSection.tsx), [OverviewPage.tsx](client/src/components/overview/OverviewPage.tsx)

HTML content is sanitized with DOMPurify on the client (good), but no sanitization occurs server-side. An attacker bypassing the client (e.g., via direct API calls) can store malicious HTML that will be rendered unsanitized if DOMPurify is ever removed or bypassed.

**Fix:** Sanitize HTML server-side before storage (use a library like `sanitize-html` or `isomorphic-dompurify`).

---

## LOW / Informational

### 13. Rate Limiting is IP-Based Only
200 req/min per IP with no per-user or per-session limits. Adequate for LAN usage, but insufficient if exposed to the internet.

### 14. Error Messages May Leak Schema Info
[sqlQuery.ts:86-89](server/src/routes/sqlQuery.ts#L86-L89) — SQLite error messages are partially stripped but could still reveal table/column names.

### 15. SSL Certificate Path in Environment Variables
[index.ts:8-11](server/src/index.ts#L8-L11) — SSL private key path in env vars could leak via `/proc` or process listing. Low risk in typical deployments.

### 16. No Audit Logging for Credential Access
Credential reads, exports, and clipboard copies are not logged. No way to detect credential exfiltration.

---

## Positive Security Patterns Already in Place

- All SQL value parameters are properly parameterized via `better-sqlite3` prepared statements
- SQL query route uses a separate readonly database connection
- CORS origin validation with configurable allowlist
- Rate limiting on API and upload routes
- Body size limits (1MB default, 10MB for uploads)
- DOMPurify for client-side HTML sanitization
- Filename sanitization in validation.ts
- Input validation helpers (requireString, requireOneOf, validateMac, etc.)
- No `eval()`, `new Function()`, or other code injection risks in parsers
- No hardcoded secrets in source code
- `.env.example` only (no real credentials committed)

---

## Recommended Fix Priority

| Priority | Finding | Effort |
|----------|---------|--------|
| P0 | #1 SQL Query cross-project data leak | Small |
| P0 | #3 Encrypt credentials at rest | Medium |
| P1 | #5 Password field `type="text"` | Trivial |
| P1 | #8 Remove password from search filter | Trivial |
| P1 | #10 Default backup credentials to false | Trivial |
| P1 | #6 Add security headers (helmet) | Small |
| P2 | #12 Server-side HTML sanitization | Small |
| P2 | #9 MIME magic byte validation | Medium |
| P2 | #7 CORS null origin handling | Small |
| P2 | #2 Authentication system | Large |
| P3 | #4 Document ORDER BY safety | Trivial |
| P3 | #11 CSV row count limit | Small |
| P3 | #16 Credential access audit logging | Medium |

## Verification

After implementing fixes:
1. Run `npm test` to verify no regressions
2. Test SQL query route: verify `SELECT * FROM credentials` only returns current project's data
3. Test backup export: verify credentials excluded by default
4. Test credential search: verify password field no longer searchable
5. Inspect network tab: verify security headers present on all responses
6. Test password form field: verify input is masked
