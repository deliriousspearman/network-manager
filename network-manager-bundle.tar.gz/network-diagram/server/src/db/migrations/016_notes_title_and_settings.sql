ALTER TABLE command_outputs ADD COLUMN title TEXT;

CREATE TABLE IF NOT EXISTS app_settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

INSERT OR IGNORE INTO app_settings (key, value) VALUES ('timezone', 'UTC');
