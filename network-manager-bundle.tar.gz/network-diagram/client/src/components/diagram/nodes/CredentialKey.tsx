interface Props {
  used: boolean;
  size?: string;
}

export function CredentialKey({ used, size = '1.6rem' }: Props) {
  const color = used ? '#16a34a' : '#ea850d';
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 16 16"
      width={size}
      height={size}
      fill={color}
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M16 5.5C16 8.53757 13.5376 11 10.5 11H7V13H5V15L4 16H0V12L5.16351 6.83649C5.0567 6.40863 5 5.96094 5 5.5C5 2.46243 7.46243 0 10.5 0C13.5376 0 16 2.46243 16 5.5ZM13 4C13 4.55228 12.5523 5 12 5C11.4477 5 11 4.55228 11 4C11 3.44772 11.4477 3 12 3C12.5523 3 13 3.44772 13 4Z"
      />
    </svg>
  );
}
